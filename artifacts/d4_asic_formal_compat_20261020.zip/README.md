# A3 Formality metadata compatibility evidence

The native-context metadata-only SVF run completed successfully for the fixed A3 sync-reset mapped candidate.
The evidence covers RTL-to-mapped logic equivalence with identical reference and implementation memory boundaries.
Memory macro contents remain a separate gate-level validation boundary.

- Final status: Verification SUCCEEDED; 13,758 compare points matched and passed; zero failing and unmatched points.
- Native log scan: console.log, formality.log, and fm_shell_command.log; no native Error lines.
- Key accepted guidance: architecture 22/22, boundary 21/21, datapath 87/88 (one rejected, matching baseline), multiplier 81/81.
- Memory boundaries: 19 instances on each side, identical expected macro designs.
- Same source: source MD5 in SVF metadata matches the recorded actual source MD5; the workspace acceptance script rehashes the local source file.
- Metadata transformation: only guide_info -file metadata was reduced to a path+MD5 pair; the recorded operative guidance SHA256 is unchanged.
- Native sidefile context: d1/ helper inventory hash and 169-file count are recorded; helper files themselves are not included.
- Completion limit: Formality did not print a separate completed-run zero-unverified counter; acceptance uses its final success status, all 13,758 passing points, zero-failing summary, and no-unmatched report.
- Historical boundary evidence: no-SVF failure, isolated CRCpair 124-unverified stall, and original triple-metadata parse error are preserved as hashes/counts/paths in prior_boundary_evidence.json.
- The original run_summary.json keeps its negative wrapper classification unchanged and is hash-bound by the post-review record.

The allowlist archive contains logs, reports, JSON metadata, and the two compatibility scripts plus collector/checker code. It contains no SVF, netlist, PDK/IP, or native helper payloads.

Run from the repository root: `python scripts/accept_d4_asic_formal_compat.py --evidence-dir artifacts/d4_asic_formal_compat_20261020 --archive artifacts/d4_asic_formal_compat_20261020.zip`.
