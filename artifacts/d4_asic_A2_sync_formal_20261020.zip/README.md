# A2 sync-reset RTL-to-mapped Formality result

Status: **EQUIVALENCE_PASS**

The proof targets `asic_A2_sync_reset_tt_20261020` with mapped SHA256 `7a42e9c61090181cee0c8212e0cf65f83693f1bdfb1027948b108290dbd5c0bd` and reset policy `hdlin_ff_always_sync_set_reset=1`; reported area is 9147690.068825 um2.

Formality final summary: 13718 matched, 13718 passing, zero-failing=True, no-unmatched=True.
The independently parsed RTL and mapped top interfaces contain 252 matching output bits; the declared requirement is 252.
The reference and implementation each retain 11 black-box instances (3 SRAM and 8 weight ROM); native proof log Error lines: 0.

The one match-only preflight completed with 13718 named points, zero native Error lines, and no unmatched points. The original wrapper misclassified its black-box report because it read the cell-type column as the design name; `match_postreview.json` preserves the original run summary and records the corrected report parse.

The native-context adapter changed only the `guide_info -file` numeric metadata field, retained the source path and verified source MD5, and confirmed the operative SVF guidance hash is unchanged. Native `d1` helpers remain in place at the remote export location; the package records their file count and inventory SHA256 without copying their contents.

Evidence includes the export/parser and match-only preflight logs, full proof logs/reports, fixed-input hash manifest, run summaries, contract scripts, and local checksum validation. No SVF, helper payload, netlist, RTL, or library contents are included.

Validate the package from the repository root with `python scripts/accept_d4_asic_A2_sync_formal.py --evidence-dir artifacts/d4_asic_A2_sync_formal_20261020 --archive artifacts/d4_asic_A2_sync_formal_20261020.zip`.
